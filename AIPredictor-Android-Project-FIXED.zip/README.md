# AI Predictor - Native Android App
Open in Android Studio or build via ./gradlew assembleDebug.