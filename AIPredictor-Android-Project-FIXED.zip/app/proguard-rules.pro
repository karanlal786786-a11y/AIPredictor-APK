# Project-specific R8 rules. Release minification is currently disabled.
