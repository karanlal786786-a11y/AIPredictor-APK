package com.aipredictor.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.aipredictor.app.service.FloatingOverlayService
import com.aipredictor.app.ui.screens.MainScreen
import com.aipredictor.app.ui.theme.AIPredictorTheme

class MainActivity : ComponentActivity() {

    private var hasOverlayPermission by mutableStateOf(false)
    private var hasNotificationPermission by mutableStateOf(false)

    // Launcher for Android 13+ Notification Permission
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
        if (isGranted) {
            Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show()
        }
    }

    // Launcher for Overlay Permission (Settings screen redirect)
    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkPermissions()
        if (hasOverlayPermission) {
            Toast.makeText(this, "Overlay permission granted! Starting service...", Toast.LENGTH_SHORT).show()
            startFloatingOverlayService()
        } else {
            Toast.makeText(
                this,
                "Permission denied: 'Display over other apps' is required for the floating overlay",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkPermissions()

        setContent {
            AIPredictorTheme {
                val isOverlayActive by FloatingOverlayService.isServiceRunning.collectAsState()

                MainScreen(
                    isOverlayActive = isOverlayActive,
                    hasOverlayPermission = hasOverlayPermission,
                    hasNotificationPermission = hasNotificationPermission,
                    onStartOverlayClicked = {
                        handleStartOverlay()
                    },
                    onStopOverlayClicked = {
                        stopFloatingOverlayService()
                    },
                    onRequestOverlayPermission = {
                        requestOverlayPermission()
                    },
                    onRequestNotificationPermission = {
                        requestNotificationPermission()
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }

    private fun checkPermissions() {
        hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        hasNotificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun handleStartOverlay() {
        if (!hasOverlayPermission) {
            Toast.makeText(
                this,
                "Grant 'Display over other apps' permission to enable floating overlay",
                Toast.LENGTH_SHORT
            ).show()
            requestOverlayPermission()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            requestNotificationPermission()
        }

        startFloatingOverlayService()
    }

    private fun startFloatingOverlayService() {
        FloatingOverlayService.startService(this)
        Toast.makeText(this, "AI Predictor overlay started!", Toast.LENGTH_SHORT).show()
    }

    private fun stopFloatingOverlayService() {
        FloatingOverlayService.stopService(this)
        Toast.makeText(this, "AI Predictor overlay stopped", Toast.LENGTH_SHORT).show()
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}