package com.aipredictor.app.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF070A12)
val DarkSurface = Color(0xFF101521)
val DarkSurfaceElevated = Color(0xFF171E2C)
val DarkBorder = Color(0xFF2A3445)
val TextPrimary = Color(0xFFF4F7FB)
val TextSecondary = Color(0xFFB8C2D1)
val TextMuted = Color(0xFF667085)
val NeonCyan = Color(0xFF00E5FF)
val NeonGreen = Color(0xFF39FF88)
val NeonPurple = Color(0xFF9B5CFF)
val DangerRed = Color(0xFFFF4D6D)
