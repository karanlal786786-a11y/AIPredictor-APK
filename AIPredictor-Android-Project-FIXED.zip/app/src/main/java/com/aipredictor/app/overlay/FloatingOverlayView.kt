package com.aipredictor.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import com.aipredictor.app.R
import kotlin.random.Random

class FloatingOverlayView(
    private val context: Context,
    private val onExitRequested: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var rootView: View? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    private var currentPrediction: Int = 7
    private var isExpanded: Boolean = true

    fun show() {
        if (rootView != null) return

        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.layout_floating_overlay, null)
        rootView = view

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 200
        }

        setupViews(view)
        setupDragTouchListener(view)

        windowManager.addView(view, layoutParams)
    }

    private fun setupViews(view: View) {
        val tvNumber = view.findViewById<TextView>(R.id.tv_prediction_number)
        val tvMeta = view.findViewById<TextView>(R.id.tv_prediction_meta)
        val tvMinimizedBadge = view.findViewById<TextView>(R.id.tv_minimized_badge)
        val layoutExpanded = view.findViewById<View>(R.id.layout_expanded)
        val layoutMinimized = view.findViewById<View>(R.id.layout_minimized)

        val btnChange = view.findViewById<Button>(R.id.btn_change)
        val btnHide = view.findViewById<Button>(R.id.btn_hide)
        val btnExit = view.findViewById<Button>(R.id.btn_exit)

        updatePredictionDisplay(currentPrediction)

        btnChange.setOnClickListener {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            val newNumber = generateNextPrediction()
            updatePredictionDisplay(newNumber)
        }

        btnHide.setOnClickListener {
            isExpanded = false
            layoutExpanded.visibility = View.GONE
            layoutMinimized.visibility = View.VISIBLE
        }

        layoutMinimized.setOnClickListener {
            isExpanded = true
            layoutMinimized.visibility = View.GONE
            layoutExpanded.visibility = View.VISIBLE
        }

        btnExit.setOnClickListener {
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            onExitRequested()
        }
    }

    fun generateNextPrediction(): Int {
        var next = Random.nextInt(1, 10)
        if (next == currentPrediction) {
            next = ((currentPrediction % 9) + 1)
        }
        currentPrediction = next
        return next
    }

    fun updatePredictionDisplay(number: Int) {
        currentPrediction = number
        rootView?.let { view ->
            val tvNumber = view.findViewById<TextView>(R.id.tv_prediction_number)
            val tvMeta = view.findViewById<TextView>(R.id.tv_prediction_meta)
            val tvMinimizedBadge = view.findViewById<TextView>(R.id.tv_minimized_badge)

            tvNumber.text = number.toString()
            tvMinimizedBadge.text = number.toString()

            val confidence = 94.0 + Random.nextDouble(0.1, 5.9)
            tvMeta.text = String.format("RNG ACCURACY: %.1f%%", confidence)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragTouchListener(view: View) {
        val dragHeader = view.findViewById<View>(R.id.header_drag_area)
        val layoutMinimized = view.findViewById<View>(R.id.layout_minimized)

        val touchListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDrag = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDrag = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()

                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                            isDrag = true
                        }

                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        if (rootView != null) {
                            windowManager.updateViewLayout(rootView, layoutParams)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isDrag && v == layoutMinimized) {
                            v.performClick()
                        }
                        return true
                    }
                }
                return false
            }
        }

        dragHeader.setOnTouchListener(touchListener)
        layoutMinimized.setOnTouchListener(touchListener)
    }

    fun remove() {
        rootView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            rootView = null
        }
    }
}